# Order Flow Trading Bot (Binance, spot)

A self-hosted web app that reads **real, free order flow data** from Binance
(order book depth + trade tape) and trades a combined **Order Book Imbalance
+ Cumulative Volume Delta** strategy, with a mobile-friendly dashboard.

## ⚠️ Read this before you touch live money

- This is not financial advice, and no strategy here is validated or
  guaranteed to be profitable. Order flow signals like OBI/CVD are commonly
  used but can and do produce losing streaks, especially in choppy markets.
- **Always run on Binance Testnet first** (`USE_TESTNET=true` in `.env`,
  the default). Get free testnet API keys at https://testnet.binance.vision/
- Only go live with an amount you can afford to lose completely, and start
  small. `MAX_POSITION_PCT` and `MAX_DAILY_LOSS_PCT` in `.env` are hard caps
  enforced in `backend/risk.py` — read that file and make sure you understand
  exactly what it does before relying on it.
- When creating your real Binance API key: enable **Spot & Margin Trading
  only**. Do **not** enable withdrawals. Restrict the key to your server's IP
  if you can.
- This app has no encrypted secrets vault — `.env` sits in plaintext on
  whatever machine you run it on. Don't deploy it on a shared or public
  server without locking that down yourself.
- Spot accounts can't truly "short" — the SHORT side in this bot sells an
  existing base-asset balance. If you don't hold any, short signals will
  fail to execute (by design — it won't use margin or futures unless you
  change that).

## What it actually does

- Connects to Binance's **free public WebSocket streams**
  (`depth20@100ms` + `aggTrade`) for live order flow — no data subscription
  needed.
- Computes **Order Book Imbalance** (bid vs ask resting volume in the top N
  levels) and **Cumulative Volume Delta** (net aggressor buy/sell volume
  over a rolling window).
- Fires a LONG/SHORT signal only when both agree, to cut down on noise.
- Every trade gets an automatic stop-loss and take-profit, a per-trade
  cooldown, and a daily-loss kill switch that halts the bot for the rest of
  the day if it's tripped.
- Dashboard (works on phone or desktop browser) shows live price, OBI, CVD,
  open position, balances, and a log — with Start / Stop / Close Position /
  Kill Switch controls.

## Setup

```bash
cd orderflow-bot
python3 -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# edit .env: add your testnet API keys, leave USE_TESTNET=true
```

Get free testnet keys (fake money, real market data) at
https://testnet.binance.vision/ — log in with GitHub, generate a key.

Run it:

```bash
uvicorn backend.server:app --host 0.0.0.0 --port 8000
```

Open `http://localhost:8000` in a browser (or from your phone, if it's on
the same network: `http://<your-computer's-LAN-IP>:8000`). Press **Start
Bot** to arm it — it will only place trades when a signal fires; watching
the dashboard without pressing Start is completely passive.

## Going live (only after you've tested thoroughly)

1. Create a real Binance API key with Spot & Margin Trading enabled,
   withdrawals disabled.
2. Put those keys in `.env`, set `USE_TESTNET=false`.
3. Start with a tiny `MAX_POSITION_PCT` (e.g. 0.01) and a tight
   `MAX_DAILY_LOSS_PCT`.
4. Restart the app. Watch it closely for the first several sessions.

## Tuning the strategy

All in `.env`, no code changes needed:

| Variable | What it does |
|---|---|
| `SYMBOL` | Trading pair, e.g. `BTCUSDT`, `ETHUSDT` |
| `OBI_LEVELS` | How many order book levels to average for imbalance |
| `OBI_THRESHOLD` | How skewed the book must be to count as a signal (0.5–1.0) |
| `CVD_WINDOW_SECONDS` | Rolling window for aggressor-flow calculation |
| `STOP_LOSS_PCT` / `TAKE_PROFIT_PCT` | Exit distances from entry |
| `COOLDOWN_SECONDS` | Minimum gap between trades |

## Extending to futures/indices

There's no free legitimate order-flow feed for traditional futures/indices —
you'd need a paid data subscription (e.g. a CME market data feed, or a
broker's DOM API). The architecture here separates data (`exchange_feed.py`)
from strategy (`strategy.py`) from execution (`executor.py`) specifically so
you can swap in a different data source later without touching the rest.
